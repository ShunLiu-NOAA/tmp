Modifications of codes:
1. $UFS_FV3_DIR/FV3/atmos_cubed_sphere/tools/fv_iau_mod.F90
Directly reading analysis increments at FV3-LAM model grids, mainly at the subroutine read_iau_forcing.
Adding wa_inc in iau_internal_data_type and iau_external_data_type definations.
Reading in the 2-D latitude and lontitude fields (you can remove it).

2. $UFS_FV3_DIR/FV3/atmos_cubed_sphere/driver/fvGFS/atmosphere.F90
Directly updating w with wa_inc.

External executable to create analysis increments
write_iau_inc.f90 
ifort -o WRITE_IAU_INC.exe -I$NETCDF/include -L$NETCDF/lib -lnetcdff -lnetcdf -g -traceback write_iau_inc.F90
Pay attention: check the variables in your own dynvar and tracer output. You may need to modify the code to read in and output tracer variables of your own run.